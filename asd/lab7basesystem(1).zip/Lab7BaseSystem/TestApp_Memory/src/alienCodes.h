/******************************************************************************/
#ifndef XTFT_ALIENCODE_H
#define XTFT_ALIENCODE_H

#include "xbasic_types.h"

#define XTFT_ALIEN_WIDTH       12
#define XTFT_ALIEN_HEIGHT      9

extern Xuint16 XTft_vidAliens[6][9];
		
#endif
