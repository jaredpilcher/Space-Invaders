#define TESTAPP_GEN

/* $Id: ddr_header.h,v 1.1 2005/10/10 18:46:01 sjen Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus DdrSelfTestExample(Xuint16 DeviceId);


