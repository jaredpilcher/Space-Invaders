#define TESTAPP_GEN

/* $Id: sysace_header.h,v 1.1 2006/02/17 21:52:36 moleres Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus SysAceSelfTestExample(Xuint16 DeviceId);


