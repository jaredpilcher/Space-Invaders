#ifndef _FSL_H
#define _FSL_H

#include "xpseudo_asm.h"        /* Legacy reasons. We just have to include this guy who defines the FSL stuff */

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif /* _FSL_H */

